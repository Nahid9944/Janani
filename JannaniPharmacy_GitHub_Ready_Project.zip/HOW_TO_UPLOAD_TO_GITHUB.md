
1) Create a new GitHub repo (e.g. JannaniPharmacyApp).
2) Upload all files from this ZIP (use Upload files on GitHub or push via git).
3) After push, go to Actions -> wait for "Android Build" workflow to finish.
4) Download artifact app-debug-apk and install on your Android 10+ phone.
