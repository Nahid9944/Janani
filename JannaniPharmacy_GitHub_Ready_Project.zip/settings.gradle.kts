rootProject.name = "JannaniPharmacyApp"
include(":app")
