package com.jannani.pharmacy;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SellProductActivity extends AppCompatActivity {

    private static final int REQ_SCAN_TEXT = 1001;

    private EditText etSearch;
    private ListView listProducts;
    private TextView tvCartSummary, tvSellMessage;

    private List<Product> allProducts = new ArrayList<>();
    private List<Product> filtered = new ArrayList<>();
    private List<Product> cart = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell_product);

        Button btnBack = findViewById(R.id.btnBackSell);
        etSearch = findViewById(R.id.etSearch);
        Button btnScan = findViewById(R.id.btnScan);
        listProducts = findViewById(R.id.listProducts);
        tvCartSummary = findViewById(R.id.tvCartSummary);
        tvSellMessage = findViewById(R.id.tvSellMessage);
        Button btnSell = findViewById(R.id.btnSell);

        btnBack.setOnClickListener(v -> finish());

        allProducts = DataStore.getProducts(this);
        filtered.addAll(allProducts);
        updateList();

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                filterProducts(s.toString());
            }
        });

        listProducts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Product p = filtered.get(position);
                cart.add(p);
                updateCartSummary();
            }
        });

        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SellProductActivity.this, ScanTextActivity.class);
                startActivityForResult(i, REQ_SCAN_TEXT);
            }
        });

        btnSell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finalizeSale();
            }
        });
    }

    private void filterProducts(String q) {
        filtered.clear();
        if (q == null || q.trim().isEmpty()) {
            filtered.addAll(allProducts);
        } else {
            String lower = q.toLowerCase();
            for (Product p : allProducts) {
                if ((p.name != null && p.name.toLowerCase().contains(lower)) ||
                        (p.company != null && p.company.toLowerCase().contains(lower))) {
                    filtered.add(p);
                }
            }
        }
        updateList();
    }

    private void updateList() {
        List<String> labels = new ArrayList<>();
        for (Product p : filtered) {
            labels.add(p.name + " (" + p.company + ") - স্টক: " + p.quantity);
        }
        listProducts.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
    }

    private void updateCartSummary() {
        if (cart.isEmpty()) {
            tvCartSummary.setText("কার্ট খালি");
            return;
        }
        double total = 0;
        StringBuilder sb = new StringBuilder();
        for (Product p : cart) {
            total += p.sellPrice;
            sb.append(p.name).append(", ");
        }
        tvCartSummary.setText("কার্ট: " + sb.toString() + "\nমোট দাম: " + total + " টাকা");
    }

    private void finalizeSale() {
        if (cart.isEmpty()) {
            tvSellMessage.setText("কার্ট খালি।");
            return;
        }

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("পেমেন্ট মোড");
        String[] items = new String[]{"পূর্ণ টাকা (ক্যাশ)", "বাকি থাকবে"};
        b.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                boolean isDue = (which == 1);
                handleSale(isDue);
            }
        });
        b.show();
    }

    private void handleSale(boolean isDue) {
        double totalSell = 0;
        double totalBuy = 0;

        List<Product> products = DataStore.getProducts(this);

        for (Product c : cart) {
            totalSell += c.sellPrice;
            totalBuy += c.buyPrice;

            for (Product p : products) {
                if (p.id == c.id && p.quantity > 0) {
                    p.quantity -= 1;
                }
            }
        }

        double profit = totalSell - totalBuy;

        String customerName = "";
        String customerPhone = "";

        if (isDue) {
            customerName = "বাকি গ্রাহক";
            customerPhone = "";
            DataStore.addOrUpdateCustomerDue(this, customerName, customerPhone, totalSell);
        }

        long now = System.currentTimeMillis();
        for (Product c : cart) {
            SaleRecord s = new SaleRecord(
                    System.currentTimeMillis(),
                    now,
                    c.id,
                    c.name,
                    1,
                    c.buyPrice,
                    c.sellPrice,
                    (c.sellPrice - c.buyPrice),
                    isDue,
                    customerName,
                    customerPhone
            );
            DataStore.addSale(this, s);
        }

        DataStore.saveProducts(this, products);
        cart.clear();
        tvSellMessage.setText("বিক্রি সম্পন্ন হয়েছে। লাভ (প্রায়): " + profit + " টাকা");
        allProducts = products;
        filterProducts(etSearch.getText().toString());
        updateCartSummary();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SCAN_TEXT && resultCode == RESULT_OK && data != null) {
            String text = data.getStringExtra("scanned_text");
            if (text != null && !text.isEmpty()) {
                String firstLine = text.split("\n")[0].trim();
                String[] parts = firstLine.split(" ");
                String keyword = parts[0];
                etSearch.setText(keyword);
                filterProducts(keyword);
                Product p = DataStore.findProductByName(this, keyword);
                if (p != null) {
                    cart.add(p);
                    updateCartSummary();
                    tvSellMessage.setText("স্ক্যান থেকে প্রডাক্ট পাওয়া গেছে: " + p.name);
                } else {
                    tvSellMessage.setText("স্ক্যান থেকে কোনো মিল পাওয়া যায়নি।");
                }
            }
        }
    }
}