package com.jannani.pharmacy;

public class CompanyReceive {
    public long id;
    public long date;
    public String companyName;
    public double amount;

    public CompanyReceive(long id, long date, String companyName, double amount) {
        this.id = id;
        this.date = date;
        this.companyName = companyName;
        this.amount = amount;
    }
}