
package com.jannani.pharmacy;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class EmployeeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);

        Button btnBack = findViewById(R.id.btnBackGeneric);
        TextView tvTitle = findViewById(R.id.tvTitle);
        ListView list = findViewById(R.id.listItems);
        TextView tvSummary = findViewById(R.id.tvSummary);
        Button btnAdd = findViewById(R.id.btnAdd);

        tvTitle.setText("কর্মচারীদের হিসাব");

        btnBack.setOnClickListener(v -> finish());
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvSummary.setText("নতুন এন্ট্রি যোগ করার জন্য পরের ভার্সনে ফর্ম যোগ করা হবে।");
            }
        });

        
        List<EmployeeRecord> listData = DataStore.getEmployees(this);
        List<String> labels = new ArrayList<>();
        double totalSalary = 0;
        double totalPaid = 0;
        for (EmployeeRecord e : listData) {
            totalSalary += e.salary;
            totalPaid += e.paid;
            labels.add(e.name + " | বেতন: " + e.salary + " | দিয়েছি: " + e.paid + " | " + e.note);
        }
        list.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
        tvSummary.setText("মোট বেতন: " + totalSalary + " | মোট প্রদান: " + totalPaid);

    }
}
