
package com.jannani.pharmacy;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MonthlySummaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monthly_summary);

        Button btnBack = findViewById(R.id.btnBackGeneric);
        TextView tvTitle = findViewById(R.id.tvTitle);
        ListView list = findViewById(R.id.listItems);
        TextView tvSummary = findViewById(R.id.tvSummary);
        Button btnAdd = findViewById(R.id.btnAdd);

        tvTitle.setText("মাসিক হিসেব");

        btnBack.setOnClickListener(v -> finish());
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvSummary.setText("নতুন এন্ট্রি যোগ করার জন্য পরের ভার্সনে ফর্ম যোগ করা হবে।");
            }
        });

        
        SimpleDateFormat monthFmt = new SimpleDateFormat("yyyy-MM", Locale.getDefault());
        String thisMonth = monthFmt.format(new Date());

        List<String> labels = new ArrayList<>();
        double totalSell = 0;
        double totalProfit = 0;
        double totalExpense = 0;

        for (SaleRecord s : DataStore.getSales(this)) {
            String m = monthFmt.format(new Date(s.date));
            if (thisMonth.equals(m)) {
                totalSell += s.sellTotal;
                totalProfit += s.profit;
            }
        }
        for (ExpenseRecord e : DataStore.getExpenses(this)) {
            String m = monthFmt.format(new Date(e.date));
            if (thisMonth.equals(m)) {
                totalExpense += e.amount;
            }
        }

        labels.add("এই মাসের মোট বিক্রি: " + totalSell + " টাকা");
        labels.add("এই মাসের মোট লাভ: " + totalProfit + " টাকা");
        labels.add("এই মাসের মোট খরচ: " + totalExpense + " টাকা");

        list.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
        tvSummary.setText("মাসিক সারাংশ উপরে দেওয়া হলো।");

    }
}
