/**
 * জননী ফার্মেসী – Hopweb HTML/JS অ্যাপ (Full Offline + OCR + হিসাব)
 * সব ডাটা localStorage-এ থাকবে।
 * ইন্টারনেট থাকলে Tesseract.js লোড হয়ে স্ক্যান মোড কাজ করবে।
 */

const App = {
  password: "994400mn",
  user: null,
  keys: {
    products: "jp_products",
    sales: "jp_sales",
    expenses: "jp_expenses",
    compReceive: "jp_comp_receive",
    compPay: "jp_comp_pay",
    employees: "jp_employees",
    dues: "jp_dues"
  },
  state: {
    products: [],
    sales: [],
    expenses: [],
    compReceive: [],
    compPay: [],
    employees: [],
    dues: []
  }
};

// ---------- Utils ----------
App.loadAll = function () {
  for (const k in App.keys) {
    try {
      App.state[k] = JSON.parse(localStorage.getItem(App.keys[k]) || "[]");
    } catch {
      App.state[k] = [];
    }
  }
};

App.saveAll = function () {
  for (const k in App.keys) {
    localStorage.setItem(App.keys[k], JSON.stringify(App.state[k]));
  }
};

App.formatDate = function (d) {
  if (!d) d = new Date();
  if (!(d instanceof Date)) d = new Date(d);
  return d.toISOString().slice(0,10);
};
App.today = function () { return App.formatDate(new Date()); };

// ---------- Init ----------
App.init = function () {
  App.loadAll();
  document.getElementById("btnBackMenu").onclick = App.showMenu;

  const saved = localStorage.getItem("jp_user");
  if (saved) {
    App.user = saved;
    App.showMenu();
  } else {
    document.getElementById("loginSection").classList.remove("hidden");
  }

  document.getElementById("btnLogin").onclick = () => {
    const name = document.getElementById("loginName").value.trim();
    const pass = document.getElementById("loginPassword").value.trim();
    const msg = document.getElementById("loginMsg");
    if (pass !== App.password) {
      msg.textContent = "পাসওয়ার্ড ভুল, আবার চেষ্টা করুন";
      return;
    }
    if (!name) {
      msg.textContent = "আপনার নাম লিখুন";
      return;
    }
    App.user = name;
    localStorage.setItem("jp_user", name);
    msg.textContent = "";
    App.showMenu();
  };

  document.getElementById("btnExitApp").onclick = () => {
    if (confirm("অ্যাপ থেকে বের হতে চান?")) {
      alert("Hopweb / ব্রাউজার থেকে বের হতে ব্যাক বাটন ব্যবহার করুন।");
    }
  };
};

App.showMenu = function () {
  document.getElementById("loginSection").classList.add("hidden");
  document.getElementById("pageSection").classList.add("hidden");
  document.getElementById("menuSection").classList.remove("hidden");
  document.getElementById("menuUserLabel").textContent = "ইউজার: " + (App.user || "");

  const items = [
    "১. প্রোডাক্ট যোগ করুন",
    "২. প্রোডাক্ট বিক্রি করুন",
    "৩. মোট প্রোডাক্ট ও স্টক",
    "৪. আজকের হিসেব",
    "৫. মোট বিক্রির হিসাব",
    "৬. মেয়াদ দেখুন",
    "৭. গ্রাহকের বাকি হিসাব",
    "৮. মোট লাভ",
    "৯. কোম্পানির টাকা পাবে",
    "১০. কোম্পানি মোট টাকা পরিশোধ",
    "১১. অন্যান্য খরচ",
    "১২. কর্মচারীদের হিসাব",
    "১৩. মোট বিক্রি",
    "১৪. মাসিক হিসেব"
  ];
  const grid = document.getElementById("menuGrid");
  grid.innerHTML = "";
  items.forEach((label, i) => {
    const b = document.createElement("button");
    b.textContent = label;
    b.onclick = () => App.openPage(i+1);
    grid.appendChild(b);
  });
};

App.openPage = function (no) {
  document.getElementById("menuSection").classList.add("hidden");
  document.getElementById("pageSection").classList.remove("hidden");
  const title = document.getElementById("pageTitle");
  const content = document.getElementById("pageContent");
  content.innerHTML = "";

  switch(no) {
    case 1: title.textContent="প্রোডাক্ট যোগ করুন"; App.renderAddProduct(content); break;
    case 2: title.textContent="প্রোডাক্ট বিক্রি করুন"; App.renderSell(content); break;
    case 3: title.textContent="মোট প্রোডাক্ট ও স্টক"; App.renderStock(content); break;
    case 4: title.textContent="আজকের হিসেব"; App.renderToday(content); break;
    case 5: title.textContent="মোট বিক্রির হিসাব"; App.renderTotalSales(content); break;
    case 6: title.textContent="মেয়াদ দেখুন"; App.renderExpiry(content); break;
    case 7: title.textContent="গ্রাহকের বাকি হিসাব"; App.renderDue(content); break;
    case 8: title.textContent="মোট লাভ"; App.renderProfit(content); break;
    case 9: title.textContent="কোম্পানির টাকা পাবে"; App.renderCompanyReceive(content); break;
    case 10:title.textContent="কোম্পানি মোট টাকা পরিশোধ"; App.renderCompanyPay(content); break;
    case 11:title.textContent="অন্যান্য খরচ"; App.renderExpense(content); break;
    case 12:title.textContent="কর্মচারীদের হিসাব"; App.renderEmployee(content); break;
    case 13:title.textContent="মোট বিক্রি"; App.renderTotalSales(content); break;
    case 14:title.textContent="মাসিক হিসেব"; App.renderMonthly(content); break;
  }
};

// ---------- প্রোডাক্ট যোগ ----------
App.renderAddProduct = function (root) {
  const div = document.createElement("div");
  div.innerHTML = `
    <div class="flex">
      <div>
        <label>প্রোডাক্টের নাম</label>
        <input id="p_name" placeholder="যেমন: Napa 500">
      </div>
      <div>
        <label>কোম্পানির নাম</label>
        <input id="p_company" placeholder="যেমন: Square">
      </div>
    </div>
    <div class="flex">
      <div>
        <label>বিক্রয় মূল্য</label>
        <input id="p_sell" type="number" step="0.01">
      </div>
      <div>
        <label>ক্রয় মূল্য (অটো ১২% কম, চাইলে বদলান)</label>
        <input id="p_buy" type="number" step="0.01">
      </div>
      <div>
        <label>পরিমাণ</label>
        <input id="p_qty" type="number">
      </div>
    </div>
    <div class="flex">
      <div>
        <label>মেয়াদ শেষের তারিখ</label>
        <input id="p_exp" type="date">
      </div>
      <div>
        <label>পেমেন্ট</label>
        <select id="p_pay">
          <option value="paid">পেইড</option>
          <option value="due">বাকি</option>
        </select>
      </div>
    </div>
    <p class="small">বিক্রয় মূল্য লিখলে ক্রয় মূল্য অটো ১২% কমে বসবে।</p>
    <div class="flex">
      <div><button id="btnAddCancel">বাদ দিন</button></div>
      <div><button id="btnAddSave">ADD করুন</button></div>
    </div>
    <p id="addMsg"></p>
  `;
  root.appendChild(div);

  const sellInput = div.querySelector("#p_sell");
  const buyInput = div.querySelector("#p_buy");
  sellInput.oninput = () => {
    const v = parseFloat(sellInput.value || "0");
    if (v>0) buyInput.value = Math.round(v*0.88*100)/100;
  };

  div.querySelector("#btnAddCancel").onclick = App.showMenu;
  div.querySelector("#btnAddSave").onclick = () => {
    const name = div.querySelector("#p_name").value.trim();
    const comp = div.querySelector("#p_company").value.trim();
    const sell = parseFloat(sellInput.value || "0");
    const buy = parseFloat(buyInput.value || "0");
    const qty = parseInt(div.querySelector("#p_qty").value || "0",10);
    const exp = div.querySelector("#p_exp").value || "";
    const pay = div.querySelector("#p_pay").value;
    const msg = div.querySelector("#addMsg");

    if (!name || !comp || !sell || !buy || !qty || !exp) {
      msg.textContent = "সব ঘর সঠিকভাবে পূরণ করুন।";
      msg.className = "error";
      return;
    }
    const p = {
      id: Date.now(),
      name, company: comp,
      sellPrice: sell,
      buyPrice: buy,
      qty,
      expiry: exp,
      payment: pay
    };
    App.state.products.push(p);
    App.saveAll();
    msg.textContent = "সঠিকভাবে প্রোডাক্ট যোগ হয়েছে।";
    msg.className = "success";
    div.querySelectorAll("input").forEach(i=>i.value="");
    div.querySelector("#p_pay").value = "paid";
  };
};

// ---------- প্রোডাক্ট বিক্রি ----------
App.renderSell = function (root) {
  const div = document.createElement("div");
  div.innerHTML = `
    <div class="flex">
      <div>
        <label>ম্যানুয়াল সার্চ</label>
        <input id="s_query" placeholder="নাম বা কোম্পানি লিখুন...">
      </div>
      <div>
        <label>স্ক্যান মোড (ক্যামেরা)</label>
        <input id="s_camera" type="file" accept="image/*" capture="environment">
        <span class="small">স্ক্যান করতে ইন্টারনেট থাকা দরকার (Tesseract.js)</span>
      </div>
    </div>
    <p id="s_scanMsg" class="small"></p>
    <table>
      <thead><tr><th>নাম</th><th>কোম্পানি</th><th>স্টক</th><th>দাম</th><th>+</th></tr></thead>
      <tbody id="s_list"></tbody>
    </table>

    <h3>কার্ট</h3>
    <table>
      <thead><tr><th>নাম</th><th>পরিমাণ</th><th>দাম</th><th>মোট</th><th>×</th></tr></thead>
      <tbody id="cart_list"></tbody>
    </table>
    <p id="cart_total"></p>
    <button id="btnSellCash">পূর্ণ টাকা (ক্যাশ)</button>
    <button id="btnSellDue">বাকি থাকবে</button>
    <p id="sellMsg"></p>
  `;
  root.appendChild(div);

  let cart = [];

  function renderProducts(filter) {
    const tbody = div.querySelector("#s_list");
    tbody.innerHTML = "";
    const q = (filter||"").toLowerCase();
    App.state.products.forEach(p=>{
      if (q && !(`${p.name} ${p.company}`.toLowerCase().includes(q))) return;
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${p.name}</td><td>${p.company}</td><td>${p.qty}</td><td>${p.sellPrice}</td>`;
      const td = document.createElement("td");
      const b = document.createElement("button");
      b.textContent = "+";
      b.onclick = ()=>addToCart(p);
      td.appendChild(b);
      tr.appendChild(td);
      tbody.appendChild(tr);
    });
  }

  function addToCart(p) {
    let item = cart.find(c=>c.id===p.id);
    if (!item) {
      item = { id:p.id, name:p.name, price:p.sellPrice, buy:p.buyPrice, qty:0 };
      cart.push(item);
    }
    const stock = App.state.products.find(x=>x.id===p.id).qty;
    if (item.qty >= stock) {
      alert("স্টকে আর নেই!");
      return;
    }
    item.qty++;
    renderCart();
  }

  function renderCart() {
    const tbody = div.querySelector("#cart_list");
    tbody.innerHTML = "";
    let total = 0;
    cart.forEach((c,idx)=>{
      const rowTotal = c.qty*c.price;
      total += rowTotal;
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${c.name}</td><td>${c.qty}</td><td>${c.price}</td><td>${rowTotal}</td>`;
      const td = document.createElement("td");
      const b = document.createElement("button");
      b.textContent = "×";
      b.onclick = ()=>{cart.splice(idx,1);renderCart();};
      td.appendChild(b);
      tr.appendChild(td);
      tbody.appendChild(tr);
    });
    div.querySelector("#cart_total").textContent = "মোট দাম: " + total + " টাকা";
  }

  div.querySelector("#s_query").oninput = e=>renderProducts(e.target.value);

  // স্ক্যান মোড (Tesseract.js)
  div.querySelector("#s_camera").onchange = async e => {
    const file = e.target.files[0];
    const msg = div.querySelector("#s_scanMsg");
    if (!file) return;
    if (!window.Tesseract) {
      msg.textContent = "Tesseract.js লোড হয়নি, ইন্টারনেট আছে কিনা দেখুন।";
      return;
    }
    msg.textContent = "স্ক্যান হচ্ছে, একটু অপেক্ষা করুন...";
    try{
      const { data:{text} } = await Tesseract.recognize(file,'eng');
      msg.textContent = "স্ক্যান ফলাফল: " + text;
      const first = (text.split(/\s+/)[0]||"").toLowerCase();
      if (first) {
        const found = App.state.products.find(p=>p.name.toLowerCase().includes(first));
        if (found) {
          addToCart(found);
          div.querySelector("#s_query").value = first;
          renderProducts(first);
          msg.textContent += " → " + found.name + " কার্টে যোগ হয়েছে।";
        } else {
          msg.textContent += " → কোনো প্রোডাক্ট মেলেনি।";
        }
      }
    }catch(err){
      msg.textContent = "স্ক্যান করতে সমস্যা হয়েছে: " + err.message;
    }
  };

  async function finalizeSale(isDue){
    if (cart.length===0){
      div.querySelector("#sellMsg").textContent="কার্ট খালি।";
      return;
    }
    let customerName="", customerPhone="";
    if (isDue){
      customerName = prompt("গ্রাহকের নাম লিখুন:","") || "বাকি গ্রাহক";
      customerPhone = prompt("গ্রাহকের মোবাইল নম্বর লিখুন:","") || "";
    }
    const today = App.today();
    let totalSell=0,totalBuy=0,totalProfit=0;
    cart.forEach(c=>{
      const prod = App.state.products.find(p=>p.id===c.id);
      if (!prod) return;
      prod.qty -= c.qty;
      const sellTotal = c.qty*c.price;
      const buyTotal = c.qty*c.buy;
      const profit = sellTotal-buyTotal;
      totalSell += sellTotal;
      totalBuy += buyTotal;
      totalProfit += profit;
      App.state.sales.push({
        id: Date.now()+Math.random(),
        date: today,
        productId: prod.id,
        productName: prod.name,
        qty: c.qty,
        sellTotal, buyTotal, profit,
        isDue,
        customerName,
        customerPhone
      });
    });

    if (isDue){
      let due = App.state.dues.find(d=>d.customerName===customerName && d.phone===customerPhone);
      if (!due){
        due = { id:Date.now(), customerName, phone:customerPhone, amount:0 };
        App.state.dues.push(due);
      }
      due.amount += totalSell;
    }

    App.saveAll();
    cart = [];
    renderCart();
    renderProducts(div.querySelector("#s_query").value);
    div.querySelector("#sellMsg").textContent =
      "বিক্রি সম্পন্ন। মোট বিক্রি: "+totalSell+" টাকা, লাভ: "+totalProfit+" টাকা";
  }

  div.querySelector("#btnSellCash").onclick = ()=>finalizeSale(false);
  div.querySelector("#btnSellDue").onclick = ()=>finalizeSale(true);

  renderProducts("");
};

// ---------- মোট প্রোডাক্ট ও স্টক ----------
App.renderStock = function (root) {
  const tbl = document.createElement("table");
  tbl.innerHTML = `
    <thead><tr>
      <th>নাম</th><th>কোম্পানি</th><th>ক্রয়</th><th>বিক্রয়</th><th>স্টক</th><th>একক লাভ</th>
    </tr></thead><tbody></tbody>
  `;
  const tbody = tbl.querySelector("tbody");
  let totalPossProfit = 0;
  App.state.products.forEach(p=>{
    const unit = p.sellPrice - p.buyPrice;
    totalPossProfit += unit*p.qty;
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${p.name}</td><td>${p.company}</td><td>${p.buyPrice}</td><td>${p.sellPrice}</td><td>${p.qty}</td><td>${unit}</td>`;
    tbody.appendChild(tr);
  });
  root.appendChild(tbl);
  const p = document.createElement("p");
  p.textContent = "সব প্রোডাক্ট বিক্রি করলে সম্ভাব্য মোট লাভ: " + totalPossProfit + " টাকা";
  root.appendChild(p);
};

// ---------- আজকের হিসেব ----------
App.renderToday = function (root) {
  const today = App.today();
  const sales = App.state.sales.filter(s=>s.date===today);
  const exp = App.state.expenses.filter(e=>e.date===today);
  let totalSell=0,totalProfit=0,totalExp=0;

  const list = document.createElement("ul");
  sales.forEach(s=>{
    totalSell += s.sellTotal;
    totalProfit += s.profit;
    const li = document.createElement("li");
    li.textContent = `বিক্রি: ${s.productName} x${s.qty} = ${s.sellTotal} (লাভ ${s.profit})`;
    list.appendChild(li);
  });
  exp.forEach(e=>{
    totalExp += e.amount;
    const li = document.createElement("li");
    li.textContent = `খরচ: ${e.amount} - ${e.note}`;
    list.appendChild(li);
  });
  root.appendChild(list);
  const p = document.createElement("p");
  p.textContent = `আজকের মোট বিক্রি: ${totalSell} টাকা, মোট লাভ: ${totalProfit} টাকা, মোট খরচ: ${totalExp} টাকা`;
  root.appendChild(p);
};

// ---------- মোট বিক্রি / লাভ ----------
App.renderTotalSales = function (root) {
  let totalSell=0,totalProfit=0;
  const tbl = document.createElement("table");
  tbl.innerHTML = `<thead><tr><th>তারিখ</th><th>প্রোডাক্ট</th><th>Qty</th><th>বিক্রি</th><th>লাভ</th></tr></thead><tbody></tbody>`;
  const tbody = tbl.querySelector("tbody");
  App.state.sales.forEach(s=>{
    totalSell += s.sellTotal;
    totalProfit += s.profit;
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${s.date}</td><td>${s.productName}</td><td>${s.qty}</td><td>${s.sellTotal}</td><td>${s.profit}</td>`;
    tbody.appendChild(tr);
  });
  root.appendChild(tbl);
  const p = document.createElement("p");
  p.textContent = `মোট বিক্রি: ${totalSell} টাকা, মোট লাভ: ${totalProfit} টাকা`;
  root.appendChild(p);
};
App.renderProfit = App.renderTotalSales;

// ---------- মেয়াদ ----------
App.renderExpiry = function (root) {
  const today = new Date(App.today());
  const tbl = document.createElement("table");
  tbl.innerHTML = `<thead><tr><th>নাম</th><th>কোম্পানি</th><th>মেয়াদ</th><th>বাকি দিন</th></tr></thead><tbody></tbody>`;
  const tbody = tbl.querySelector("tbody");
  App.state.products.forEach(p=>{
    if (!p.expiry) return;
    const exp = new Date(p.expiry);
    const diff = Math.round((exp - today)/(1000*60*60*24));
    let cls = "badge badge-ok";
    if (diff<0) cls="badge badge-bad";
    else if (diff<=30) cls="badge badge-warn";
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${p.name}</td><td>${p.company}</td><td>${p.expiry}</td><td><span class="${cls}">${diff} দিন</span></td>`;
    tbody.appendChild(tr);
  });
  root.appendChild(tbl);
};

// ---------- গ্রাহকের বাকি ----------
App.renderDue = function (root) {
  const tbl = document.createElement("table");
  tbl.innerHTML = `<thead><tr><th>নাম</th><th>মোবাইল</th><th>মোট বাকি</th></tr></thead><tbody></tbody>`;
  const tbody = tbl.querySelector("tbody");
  let total=0;
  App.state.dues.forEach(d=>{
    total += d.amount;
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${d.customerName}</td><td>${d.phone}</td><td>${d.amount}</td>`;
    tbody.appendChild(tr);
  });
  root.appendChild(tbl);
  const p = document.createElement("p");
  p.textContent = "সব গ্রাহকের মোট বাকি: " + total + " টাকা";
  root.appendChild(p);
};

// ---------- কোম্পানির টাকা পাবে ----------
App.renderCompanyReceive = function (root) {
  const div = document.createElement("div");
  div.innerHTML = `
    <div class="flex">
      <div>
        <label>তারিখ</label>
        <input id="cr_date" type="date">
      </div>
      <div>
        <label>কোম্পানির নাম</label>
        <input id="cr_name">
      </div>
      <div>
        <label>কোম্পানির মোবাইল নম্বর</label>
        <input id="cr_phone" placeholder="যেমন: 017...">
      </div>
      <div>
        <label>মোট টাকা পাবে</label>
        <input id="cr_amount" type="number" step="0.01">
      </div>
    </div>
    <button id="cr_save">সেভ করুন</button>
    <p id="cr_msg"></p>
    <table>
      <thead><tr><th>তারিখ</th><th>নাম</th><th>কোম্পানি</th><th>মোবাইল</th><th>টাকা পাবে</th></tr></thead>
      <tbody id="cr_list"></tbody>
    </table>
  `;
  root.appendChild(div);
  div.querySelector("#cr_date").value = App.today();

  function render(){
    const tbody = div.querySelector("#cr_list");
    tbody.innerHTML = "";
    let total=0;
    App.state.compReceive.forEach(r=>{
      total += r.amount;
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${r.date}</td><td>${r.contactName||""}</td><td>${r.company}</td><td>${r.phone||""}</td><td>${r.amount}</td>`;
      tbody.appendChild(tr);
    });
    div.querySelector("#cr_msg").textContent = "মোট পাওনা: " + total + " টাকা";
  }

  div.querySelector("#cr_save").onclick = ()=>{
    const d = div.querySelector("#cr_date").value || App.today();
    const cname = (div.querySelector("#cr_name").value || "").trim();
    const phone = (div.querySelector("#cr_phone").value || "").trim();
    const amt = parseFloat(div.querySelector("#cr_amount").value || "0");
    if (!cname || !amt){
      div.querySelector("#cr_msg").textContent = "কোম্পানির নাম ও টাকা লিখুন।";
      return;
    }
    App.state.compReceive.push({
      id: Date.now(),
      date: d,
      company: cname,
      phone,
      contactName: cname,
      amount: amt
    });
    App.saveAll();
    div.querySelector("#cr_name").value="";
    div.querySelector("#cr_phone").value="";
    div.querySelector("#cr_amount").value="";
    render();
  };
  render();
};

// ---------- কোম্পানি মোট টাকা পরিশোধ ----------
App.renderCompanyPay = function (root) {
  const div = document.createElement("div");
  div.innerHTML = `
    <div class="flex">
      <div>
        <label>তারিখ</label>
        <input id="cp_date" type="date">
      </div>
      <div>
        <label>কোম্পানির নাম</label>
        <input id="cp_name">
      </div>
      <div>
        <label>কোম্পানির মোবাইল নম্বর</label>
        <input id="cp_phone" placeholder="যেমন: 017...">
      </div>
      <div>
        <label>মোট টাকা দিয়েছি</label>
        <input id="cp_amount" type="number" step="0.01">
      </div>
    </div>
    <button id="cp_save">সেভ করুন</button>
    <p id="cp_msg"></p>
    <table>
      <thead><tr><th>তারিখ</th><th>নাম</th><th>কোম্পানি</th><th>মোবাইল</th><th>টাকা দিয়েছি</th></tr></thead>
      <tbody id="cp_list"></tbody>
    </table>
  `;
  root.appendChild(div);
  div.querySelector("#cp_date").value = App.today();

  function render(){
    const tbody = div.querySelector("#cp_list");
    tbody.innerHTML = "";
    let total=0;
    App.state.compPay.forEach(r=>{
      total += r.amount;
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${r.date}</td><td>${r.contactName||""}</td><td>${r.company}</td><td>${r.phone||""}</td><td>${r.amount}</td>`;
      tbody.appendChild(tr);
    });
    div.querySelector("#cp_msg").textContent = "মোট পরিশোধ: " + total + " টাকা";
  }

  div.querySelector("#cp_save").onclick = ()=>{
    const d = div.querySelector("#cp_date").value || App.today();
    const cname = (div.querySelector("#cp_name").value || "").trim();
    const phone = (div.querySelector("#cp_phone").value || "").trim();
    const amt = parseFloat(div.querySelector("#cp_amount").value || "0");
    if (!cname || !amt){
      div.querySelector("#cp_msg").textContent = "কোম্পানির নাম ও টাকা লিখুন।";
      return;
    }
    App.state.compPay.push({
      id: Date.now(),
      date: d,
      company: cname,
      phone,
      contactName: cname,
      amount: amt
    });
    App.saveAll();
    div.querySelector("#cp_name").value="";
    div.querySelector("#cp_phone").value="";
    div.querySelector("#cp_amount").value="";
    render();
  };
  render();
};

// ---------- অন্যান্য খরচ ----------
App.renderExpense = function (root) {
  const div = document.createElement("div");
  div.innerHTML = `
    <div class="flex">
      <div>
        <label>তারিখ</label>
        <input id="ex_date" type="date">
      </div>
      <div>
        <label>টাকার পরিমাণ</label>
        <input id="ex_amount" type="number" step="0.01">
      </div>
    </div>
    <label>খরচের বর্ণনা</label>
    <textarea id="ex_note"></textarea>
    <button id="ex_save">সেভ করুন</button>
    <p id="ex_msg"></p>
    <table>
      <thead><tr><th>তারিখ</th><th>টাকা</th><th>বর্ণনা</th></tr></thead>
      <tbody id="ex_list"></tbody>
    </table>
  `;
  root.appendChild(div);
  div.querySelector("#ex_date").value = App.today();

  function render(){
    const tbody = div.querySelector("#ex_list");
    tbody.innerHTML = "";
    let total=0;
    App.state.expenses.forEach(e=>{
      total += e.amount;
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${e.date}</td><td>${e.amount}</td><td>${e.note}</td>`;
      tbody.appendChild(tr);
    });
    div.querySelector("#ex_msg").textContent = "মোট অন্যান্য খরচ: " + total + " টাকা";
  }

  div.querySelector("#ex_save").onclick = ()=>{
    const d = div.querySelector("#ex_date").value || App.today();
    const amt = parseFloat(div.querySelector("#ex_amount").value || "0");
    const note = (div.querySelector("#ex_note").value || "").trim();
    if (!amt){
      div.querySelector("#ex_msg").textContent = "টাকার পরিমাণ লিখুন।";
      return;
    }
    App.state.expenses.push({id:Date.now(),date:d,amount:amt,note});
    App.saveAll();
    div.querySelector("#ex_amount").value="";
    div.querySelector("#ex_note").value="";
    render();
  };
  render();
};

// ---------- কর্মচারীদের হিসাব ----------
App.renderEmployee = function (root) {
  const div = document.createElement("div");
  div.innerHTML = `
    <div class="flex">
      <div>
        <label>কর্মচারীর নাম</label>
        <input id="em_name">
      </div>
      <div>
        <label>বেতন</label>
        <input id="em_salary" type="number" step="0.01">
      </div>
      <div>
        <label>দিয়েছি</label>
        <input id="em_paid" type="number" step="0.01">
      </div>
    </div>
    <label>নোট</label>
    <textarea id="em_note"></textarea>
    <button id="em_save">সেভ করুন</button>
    <p id="em_msg"></p>
    <table>
      <thead><tr><th>নাম</th><th>বেতন</th><th>দিয়েছি</th><th>নোট</th></tr></thead>
      <tbody id="em_list"></tbody>
    </table>
  `;
  root.appendChild(div);

  function render(){
    const tbody = div.querySelector("#em_list");
    tbody.innerHTML = "";
    let totalSal=0,totalPaid=0;
    App.state.employees.forEach(e=>{
      totalSal += e.salary;
      totalPaid += e.paid;
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${e.name}</td><td>${e.salary}</td><td>${e.paid}</td><td>${e.note}</td>`;
      tbody.appendChild(tr);
    });
    div.querySelector("#em_msg").textContent =
      "মোট বেতন: "+totalSal+" | মোট প্রদান: "+totalPaid;
  }

  div.querySelector("#em_save").onclick = ()=>{
    const name = (div.querySelector("#em_name").value||"").trim();
    const salary = parseFloat(div.querySelector("#em_salary").value||"0");
    const paid = parseFloat(div.querySelector("#em_paid").value||"0");
    const note = (div.querySelector("#em_note").value||"").trim();
    if (!name || !salary){
      div.querySelector("#em_msg").textContent="নাম ও বেতন লিখুন।";
      return;
    }
    App.state.employees.push({id:Date.now(),name,salary,paid,note});
    App.saveAll();
    div.querySelector("#em_name").value="";
    div.querySelector("#em_salary").value="";
    div.querySelector("#em_paid").value="";
    div.querySelector("#em_note").value="";
    render();
  };
  render();
};

// ---------- মাসিক হিসেব ----------
App.renderMonthly = function (root) {
  const ym = App.today().slice(0,7); // yyyy-mm
  let totalSell=0,totalProfit=0,totalExp=0;
  App.state.sales.forEach(s=>{
    if (s.date.startsWith(ym)){
      totalSell += s.sellTotal;
      totalProfit += s.profit;
    }
  });
  App.state.expenses.forEach(e=>{
    if (e.date.startsWith(ym)){
      totalExp += e.amount;
    }
  });
  const p = document.createElement("p");
  p.textContent = `${ym} মাস পর্যন্ত মোট বিক্রি: ${totalSell} টাকা, মোট লাভ: ${totalProfit} টাকা, মোট খরচ: ${totalExp} টাকা`;
  root.appendChild(p);
};

window.addEventListener("load", App.init);