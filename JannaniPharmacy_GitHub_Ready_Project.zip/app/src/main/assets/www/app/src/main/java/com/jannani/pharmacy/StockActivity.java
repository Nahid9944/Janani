
package com.jannani.pharmacy;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class StockActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock);

        Button btnBack = findViewById(R.id.btnBackGeneric);
        TextView tvTitle = findViewById(R.id.tvTitle);
        ListView list = findViewById(R.id.listItems);
        TextView tvSummary = findViewById(R.id.tvSummary);
        Button btnAdd = findViewById(R.id.btnAdd);

        tvTitle.setText("মোট প্রোডাক্ট ও স্টক");

        btnBack.setOnClickListener(v -> finish());
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvSummary.setText("নতুন এন্ট্রি যোগ করার জন্য পরের ভার্সনে ফর্ম যোগ করা হবে।");
            }
        });

        
        List<Product> products = DataStore.getProducts(this);
        List<String> labels = new ArrayList<>();
        for (Product p : products) {
            double profitPerUnit = p.sellPrice - p.buyPrice;
            labels.add(p.name + " (" + p.company + ") - স্টক: " + p.quantity +
                    " | ক্রয়: " + p.buyPrice + " | বিক্রয়: " + p.sellPrice +
                    " | একক লাভ: " + profitPerUnit);
        }
        list.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
        tvSummary.setText("মোট প্রোডাক্ট: " + products.size());

    }
}
