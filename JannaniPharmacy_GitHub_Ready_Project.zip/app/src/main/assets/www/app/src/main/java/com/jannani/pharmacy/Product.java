package com.jannani.pharmacy;

public class Product {
    public long id;
    public String name;
    public String company;
    public double buyPrice;
    public double sellPrice;
    public int quantity;
    public String expiry;
    public String payment; // paid / due

    public Product(long id, String name, String company, double buyPrice, double sellPrice,
                   int quantity, String expiry, String payment) {
        this.id = id;
        this.name = name;
        this.company = company;
        this.buyPrice = buyPrice;
        this.sellPrice = sellPrice;
        this.quantity = quantity;
        this.expiry = expiry;
        this.payment = payment;
    }
}