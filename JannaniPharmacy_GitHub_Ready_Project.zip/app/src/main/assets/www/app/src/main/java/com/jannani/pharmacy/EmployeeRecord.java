package com.jannani.pharmacy;

public class EmployeeRecord {
    public long id;
    public String name;
    public double salary;
    public double paid;
    public String note;

    public EmployeeRecord(long id, String name, double salary, double paid, String note) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.paid = paid;
        this.note = note;
    }
}