
package com.jannani.pharmacy;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DailySummaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_summary);

        Button btnBack = findViewById(R.id.btnBackGeneric);
        TextView tvTitle = findViewById(R.id.tvTitle);
        ListView list = findViewById(R.id.listItems);
        TextView tvSummary = findViewById(R.id.tvSummary);
        Button btnAdd = findViewById(R.id.btnAdd);

        tvTitle.setText("আজকের হিসেব");

        btnBack.setOnClickListener(v -> finish());
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvSummary.setText("নতুন এন্ট্রি যোগ করার জন্য পরের ভার্সনে ফর্ম যোগ করা হবে।");
            }
        });

        
        long now = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        String today = sdf.format(new Date(now));

        List<String> labels = new ArrayList<>();
        double totalSell = 0;
        double totalProfit = 0;
        double totalExpense = 0;

        for (SaleRecord s : DataStore.getSales(this)) {
            String d = sdf.format(new Date(s.date));
            if (today.equals(d)) {
                totalSell += s.sellTotal;
                totalProfit += s.profit;
                labels.add("বিক্রি: " + s.productName + " - " + s.sellTotal + " (লাভ: " + s.profit + ")");
            }
        }
        for (ExpenseRecord e : DataStore.getExpenses(this)) {
            String d = sdf.format(new Date(e.date));
            if (today.equals(d)) {
                totalExpense += e.amount;
                labels.add("খরচ: " + e.amount + " | " + e.note);
            }
        }

        list.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
        tvSummary.setText("আজকের মোট বিক্রি: " + totalSell + " | মোট লাভ: " + totalProfit + " | মোট খরচ: " + totalExpense);

    }
}
