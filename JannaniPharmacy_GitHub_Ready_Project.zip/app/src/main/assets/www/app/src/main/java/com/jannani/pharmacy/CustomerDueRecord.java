package com.jannani.pharmacy;

public class CustomerDueRecord {
    public long id;
    public String customerName;
    public String phone;
    public double amount;

    public CustomerDueRecord(long id, String customerName, String phone, double amount) {
        this.id = id;
        this.customerName = customerName;
        this.phone = phone;
        this.amount = amount;
    }
}