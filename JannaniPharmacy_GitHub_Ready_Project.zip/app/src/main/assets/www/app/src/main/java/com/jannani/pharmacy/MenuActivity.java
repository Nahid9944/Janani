package com.jannani.pharmacy;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    private static final String[] MENU_ITEMS = new String[]{
            "১. প্রোডাক্ট যোগ করুন",
            "২. প্রোডাক্ট বিক্রি করুন",
            "৩. মোট প্রোডাক্ট ও স্টক",
            "৪. আজকের হিসেব",
            "৫. মোট বিক্রির হিসাব",
            "৬. মেয়াদ দেখুন",
            "৭. গ্রাহকের বাকি হিসাব",
            "৮. মোট লাভ",
            "৯. কোম্পানির টাকা পাবে",
            "১০. কোম্পানি মোট টাকা পরিশোধ",
            "১১. অন্যান্য খরচ",
            "১২. কর্মচারীদের হিসাব",
            "১৩. মোট বিক্রি",
            "১৪. মাসিক হিসেব"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        TextView tvUser = findViewById(R.id.tvUserLabel);
        String name = getIntent().getStringExtra("user_name");
        if (name == null) name = "";
        tvUser.setText("ইউজার: " + name);

        GridLayout grid = findViewById(R.id.gridMenu);
        grid.removeAllViews();
        for (int i = 0; i < MENU_ITEMS.length; i++) {
            Button b = new Button(this);
            b.setText(MENU_ITEMS[i]);
            b.setAllCaps(false);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            lp.setMargins(8, 8, 8, 8);
            b.setLayoutParams(lp);
            final int index = i;
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    handleMenuClick(index);
                }
            });
            grid.addView(b);
        }

        Button btnExit = findViewById(R.id.btnExitApp);
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmExit();
            }
        });
    }

    private void handleMenuClick(int index) {
        switch (index) {
            case 0:
                startActivity(new Intent(this, AddProductActivity.class));
                break;
            case 1:
                startActivity(new Intent(this, SellProductActivity.class));
                break;
            case 2:
                startActivity(new Intent(this, StockActivity.class));
                break;
            case 3:
                startActivity(new Intent(this, DailySummaryActivity.class));
                break;
            case 4:
                startActivity(new Intent(this, TotalSalesActivity.class));
                break;
            case 5:
                startActivity(new Intent(this, ExpiryActivity.class));
                break;
            case 6:
                startActivity(new Intent(this, CustomerDueActivity.class));
                break;
            case 7:
                startActivity(new Intent(this, TotalSalesActivity.class));
                break;
            case 8:
                startActivity(new Intent(this, CompanyReceiveActivity.class));
                break;
            case 9:
                startActivity(new Intent(this, CompanyPaymentActivity.class));
                break;
            case 10:
                startActivity(new Intent(this, OtherExpenseActivity.class));
                break;
            case 11:
                startActivity(new Intent(this, EmployeeActivity.class));
                break;
            case 12:
                startActivity(new Intent(this, TotalSalesActivity.class));
                break;
            case 13:
                startActivity(new Intent(this, MonthlySummaryActivity.class));
                break;
        }
    }

    private void confirmExit() {
        new AlertDialog.Builder(this)
                .setTitle("বের হবেন?")
                .setMessage("আপনি কি সত্যিই অ্যাপ থেকে বের হতে চান?")
                .setPositiveButton("হ্যাঁ", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finishAffinity();
                    }
                })
                .setNegativeButton("না", null)
                .show();
    }
}