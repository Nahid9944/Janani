package com.jannani.pharmacy;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class FirebaseSync {

    private static final String STORE_ID = "mainStore";

    private static boolean isOnline(Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            return ni != null && ni.isConnected();
        } catch (Exception e) {
            return false;
        }
    }

    public static void syncAll(Context context) {
        if (!isOnline(context)) return;

        Map<String, Object> dump = new HashMap<>();
        dump.put("lastUpdated", System.currentTimeMillis());
        // হালকা রাখার জন্য শুধু lastUpdated পাঠাচ্ছি; চাইলে পরে পূর্ণ ডাটা পাঠানো যাবে।

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("stores").child(STORE_ID);
        ref.updateChildren(dump);
    }
}