package com.jannani.pharmacy;

public class SaleRecord {
    public long id;
    public long date;
    public long productId;
    public String productName;
    public int quantity;
    public double buyTotal;
    public double sellTotal;
    public double profit;
    public boolean isDue;
    public String customerName;
    public String customerPhone;

    public SaleRecord(long id, long date, long productId, String productName, int quantity,
                      double buyTotal, double sellTotal, double profit,
                      boolean isDue, String customerName, String customerPhone) {
        this.id = id;
        this.date = date;
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.buyTotal = buyTotal;
        this.sellTotal = sellTotal;
        this.profit = profit;
        this.isDue = isDue;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
    }
}