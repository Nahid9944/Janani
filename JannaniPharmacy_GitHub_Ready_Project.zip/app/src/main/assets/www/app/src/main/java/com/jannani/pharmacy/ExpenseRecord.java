package com.jannani.pharmacy;

public class ExpenseRecord {
    public long id;
    public long date;
    public double amount;
    public String note;

    public ExpenseRecord(long id, long date, double amount, String note) {
        this.id = id;
        this.date = date;
        this.amount = amount;
        this.note = note;
    }
}