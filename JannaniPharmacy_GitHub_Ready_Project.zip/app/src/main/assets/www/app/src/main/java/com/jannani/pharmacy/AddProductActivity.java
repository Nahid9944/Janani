package com.jannani.pharmacy;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AddProductActivity extends AppCompatActivity {

    private EditText etName, etCompany, etSell, etBuy, etQty, etExpiry;
    private Spinner spPayment;
    private TextView tvMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        etName = findViewById(R.id.etName);
        etCompany = findViewById(R.id.etCompany);
        etSell = findViewById(R.id.etSellPrice);
        etBuy = findViewById(R.id.etBuyPrice);
        etQty = findViewById(R.id.etQty);
        etExpiry = findViewById(R.id.etExpiry);
        spPayment = findViewById(R.id.spPayment);
        tvMsg = findViewById(R.id.tvAddMessage);
        Button btnBack = findViewById(R.id.btnBack);
        Button btnCancel = findViewById(R.id.btnCancel);
        Button btnSave = findViewById(R.id.btnSave);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"পেইড", "বাকি"});
        spPayment.setAdapter(adapter);

        etSell.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    double sell = Double.parseDouble(s.toString());
                    double buy = Math.round(sell * 0.88);
                    etBuy.setText(String.valueOf(buy));
                } catch (Exception e) {
                    // ignore
                }
            }
        });

        btnBack.setOnClickListener(v -> finish());
        btnCancel.setOnClickListener(v -> finish());

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveProduct();
            }
        });
    }

    private void saveProduct() {
        String name = etName.getText().toString().trim();
        String company = etCompany.getText().toString().trim();
        String sellStr = etSell.getText().toString().trim();
        String buyStr = etBuy.getText().toString().trim();
        String qtyStr = etQty.getText().toString().trim();
        String expiry = etExpiry.getText().toString().trim();
        String payment = spPayment.getSelectedItemPosition() == 0 ? "paid" : "due";

        if (name.isEmpty() || company.isEmpty() || sellStr.isEmpty() ||
                buyStr.isEmpty() || qtyStr.isEmpty() || expiry.isEmpty()) {
            tvMsg.setText("সব ঘর সঠিকভাবে পূরণ করুন।");
            return;
        }

        double sell = Double.parseDouble(sellStr);
        double buy = Double.parseDouble(buyStr);
        int qty = Integer.parseInt(qtyStr);

        long newId = System.currentTimeMillis();
        Product p = new Product(newId, name, company, buy, sell, qty, expiry, payment);
        DataStore.addOrUpdateProduct(this, p);
        tvMsg.setText("সঠিকভাবে প্রডাক্ট যোগ হয়েছে।");

        etName.setText("");
        etCompany.setText("");
        etSell.setText("");
        etBuy.setText("");
        etQty.setText("");
        etExpiry.setText("");
    }
}