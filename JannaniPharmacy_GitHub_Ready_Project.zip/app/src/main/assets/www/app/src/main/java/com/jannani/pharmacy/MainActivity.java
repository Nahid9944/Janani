package com.jannani.pharmacy;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etUserName, etPassword;
    private TextView tvMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUserName = findViewById(R.id.etUserName);
        etPassword = findViewById(R.id.etPassword);
        tvMessage = findViewById(R.id.tvLoginMessage);
        Button btnEnter = findViewById(R.id.btnEnter);

        SharedPreferences prefs = getSharedPreferences("jp_prefs", MODE_PRIVATE);
        String savedUser = prefs.getString("user_name", null);
        if (savedUser != null) {
            openMenu(savedUser);
            return;
        }

        btnEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etUserName.getText().toString().trim();
                String pass = etPassword.getText().toString().trim();
                if (!"994400mn".equals(pass)) {
                    tvMessage.setText("পাসওয়ার্ড ভুল, আবার চেষ্টা করুন");
                    return;
                }
                if (name.isEmpty()) {
                    tvMessage.setText("আপনার নাম লিখুন");
                    return;
                }
                SharedPreferences.Editor ed = getSharedPreferences("jp_prefs", MODE_PRIVATE).edit();
                ed.putString("user_name", name);
                ed.apply();
                openMenu(name);
            }
        });
    }

    private void openMenu(String name) {
        Intent i = new Intent(MainActivity.this, MenuActivity.class);
        i.putExtra("user_name", name);
        startActivity(i);
        finish();
    }
}