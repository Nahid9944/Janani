
package com.jannani.pharmacy;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CustomerDueActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_due);

        Button btnBack = findViewById(R.id.btnBackGeneric);
        TextView tvTitle = findViewById(R.id.tvTitle);
        ListView list = findViewById(R.id.listItems);
        TextView tvSummary = findViewById(R.id.tvSummary);
        Button btnAdd = findViewById(R.id.btnAdd);

        tvTitle.setText("গ্রাহকের বাকি হিসাব");

        btnBack.setOnClickListener(v -> finish());
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvSummary.setText("নতুন এন্ট্রি যোগ করার জন্য পরের ভার্সনে ফর্ম যোগ করা হবে।");
            }
        });

        
        List<CustomerDueRecord> dues = DataStore.getCustomerDues(this);
        List<String> labels = new ArrayList<>();
        double totalDue = 0;
        for (CustomerDueRecord d : dues) {
            totalDue += d.amount;
            labels.add(d.customerName + " (" + d.phone + ") - বাকি: " + d.amount + " টাকা");
        }
        list.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, labels));
        tvSummary.setText("মোট বাকি: " + totalDue + " টাকা");

    }
}
