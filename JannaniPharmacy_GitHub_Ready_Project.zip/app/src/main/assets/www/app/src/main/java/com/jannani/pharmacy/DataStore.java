package com.jannani.pharmacy;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class DataStore {

    private static final String PREF_NAME = "jp_data";
    private static final String KEY_PRODUCTS = "products";
    private static final String KEY_SALES = "sales";
    private static final String KEY_EXPENSES = "expenses";
    private static final String KEY_COMPANY_RECEIVE = "company_receive";
    private static final String KEY_COMPANY_PAYMENT = "company_payment";
    private static final String KEY_EMPLOYEES = "employees";
    private static final String KEY_CUSTOMER_DUES = "customer_dues";

    private static final Gson gson = new Gson();

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    private static void save(Context context, String key, Object value) {
        SharedPreferences.Editor ed = prefs(context).edit();
        ed.putString(key, gson.toJson(value));
        ed.apply();
        FirebaseSync.syncAll(context);
    }

    private static <T> List<T> loadList(Context context, String key, Type type) {
        String json = prefs(context).getString(key, null);
        if (json == null) return new ArrayList<>();
        try {
            return gson.fromJson(json, type);
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public static List<Product> getProducts(Context context) {
        Type type = new TypeToken<ArrayList<Product>>(){}.getType();
        return loadList(context, KEY_PRODUCTS, type);
    }

    public static void saveProducts(Context context, List<Product> items) {
        save(context, KEY_PRODUCTS, items);
    }

    public static void addOrUpdateProduct(Context context, Product p) {
        List<Product> products = getProducts(context);
        boolean found = false;
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).id == p.id) {
                products.set(i, p);
                found = true;
                break;
            }
        }
        if (!found) {
            products.add(p);
        }
        saveProducts(context, products);
    }

    public static Product findProductById(Context context, long id) {
        for (Product p : getProducts(context)) {
            if (p.id == id) return p;
        }
        return null;
    }

    public static Product findProductByName(Context context, String name) {
        String lower = name.toLowerCase();
        for (Product p : getProducts(context)) {
            if (p.name != null && p.name.toLowerCase().contains(lower)) {
                return p;
            }
        }
        return null;
    }

    public static List<SaleRecord> getSales(Context context) {
        Type type = new TypeToken<ArrayList<SaleRecord>>(){}.getType();
        return loadList(context, KEY_SALES, type);
    }

    public static void saveSales(Context context, List<SaleRecord> items) {
        save(context, KEY_SALES, items);
    }

    public static void addSale(Context context, SaleRecord s) {
        List<SaleRecord> list = getSales(context);
        list.add(s);
        saveSales(context, list);
    }

    public static List<ExpenseRecord> getExpenses(Context context) {
        Type type = new TypeToken<ArrayList<ExpenseRecord>>(){}.getType();
        return loadList(context, KEY_EXPENSES, type);
    }

    public static void addExpense(Context context, ExpenseRecord e) {
        List<ExpenseRecord> list = getExpenses(context);
        list.add(e);
        save(context, KEY_EXPENSES, list);
    }

    public static List<CompanyReceive> getCompanyReceives(Context context) {
        Type type = new TypeToken<ArrayList<CompanyReceive>>(){}.getType();
        return loadList(context, KEY_COMPANY_RECEIVE, type);
    }

    public static void addCompanyReceive(Context context, CompanyReceive cr) {
        List<CompanyReceive> list = getCompanyReceives(context);
        list.add(cr);
        save(context, KEY_COMPANY_RECEIVE, list);
    }

    public static List<CompanyPayment> getCompanyPayments(Context context) {
        Type type = new TypeToken<ArrayList<CompanyPayment>>(){}.getType();
        return loadList(context, KEY_COMPANY_PAYMENT, type);
    }

    public static void addCompanyPayment(Context context, CompanyPayment cp) {
        List<CompanyPayment> list = getCompanyPayments(context);
        list.add(cp);
        save(context, KEY_COMPANY_PAYMENT, list);
    }

    public static List<EmployeeRecord> getEmployees(Context context) {
        Type type = new TypeToken<ArrayList<EmployeeRecord>>(){}.getType();
        return loadList(context, KEY_EMPLOYEES, type);
    }

    public static void addEmployee(Context context, EmployeeRecord e) {
        List<EmployeeRecord> list = getEmployees(context);
        list.add(e);
        save(context, KEY_EMPLOYEES, list);
    }

    public static List<CustomerDueRecord> getCustomerDues(Context context) {
        Type type = new TypeToken<ArrayList<CustomerDueRecord>>(){}.getType();
        return loadList(context, KEY_CUSTOMER_DUES, type);
    }

    public static void addOrUpdateCustomerDue(Context context, String name, String phone, double delta) {
        List<CustomerDueRecord> list = getCustomerDues(context);
        CustomerDueRecord found = null;
        for (CustomerDueRecord d : list) {
            if (d.customerName.equals(name) && d.phone.equals(phone)) {
                found = d;
                break;
            }
        }
        if (found == null) {
            long id = System.currentTimeMillis();
            found = new CustomerDueRecord(id, name, phone, delta);
            list.add(found);
        } else {
            found.amount += delta;
        }
        save(context, KEY_CUSTOMER_DUES, list);
    }
}