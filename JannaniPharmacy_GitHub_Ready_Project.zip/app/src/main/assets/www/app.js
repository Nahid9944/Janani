const App = {
  password: "994400mn",
  user: null,
  firebaseDb: null,
  keys: {
    products: "jp_products",
    sales: "jp_sales",
    expenses: "jp_expenses",
    compReceive: "jp_comp_receive",
    compPay: "jp_comp_pay",
    employees: "jp_employees",
    dues: "jp_dues",
    compContacts: "jp_comp_contacts"
  },
  state: {
    products: [],
    sales: [],
    expenses: [],
    compReceive: [],
    compPay: [],
    employees: [],
    dues: [],
    compContacts: []
  }
};

App.loadAll = function(){
  for(const k in App.keys){
    try{ App.state[k] = JSON.parse(localStorage.getItem(App.keys[k])||"[]"); }
    catch{ App.state[k]=[]; }
  }
};
App.saveAll = function(){
  for(const k in App.keys){
    localStorage.setItem(App.keys[k], JSON.stringify(App.state[k]));
  }
};
App.today = function(){
  return new Date().toISOString().slice(0,10);
};

// Firebase
App.initFirebase = function(){
  if(typeof firebase==="undefined") return;
  const cfg = {
    apiKey: "AIzaSyDc3kOpRpKh0IJhiEzc7Q7vX2QIhaslsAA",
    authDomain: "jannai-c78c5.firebaseapp.com",
    databaseURL: "https://jannai-c78c5-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "jannai-c78c5",
    storageBucket: "jannai-c78c5.firebasestorage.app",
    messagingSenderId: "405421018784",
    appId: "1:405421018784:android:045f085563676914c683c5"
  };
  try{
    firebase.initializeApp(cfg);
    App.firebaseDb = firebase.database();
  }catch(e){console.log(e.message);}
};
App.firebaseUpload = async function(statusEl){
  if(!App.firebaseDb){statusEl.textContent="Firebase কাজ করছে না।";return;}
  statusEl.textContent="আপলোড হচ্ছে...";
  await App.firebaseDb.ref("jannani_pharmacy/all_data").set(App.state);
  statusEl.textContent="Firebase এ ব্যাকআপ হয়েছে।";
};
App.firebaseDownload = async function(statusEl){
  if(!App.firebaseDb){statusEl.textContent="Firebase কাজ করছে না।";return;}
  statusEl.textContent="ডাউনলোড হচ্ছে...";
  const snap = await App.firebaseDb.ref("jannani_pharmacy/all_data").once("value");
  const data = snap.val();
  if(!data){statusEl.textContent="কোনো ডাটা পাওয়া যায়নি।";return;}
  for(const k in App.state){ if(data[k]) App.state[k]=data[k]; }
  App.saveAll();
  statusEl.textContent="Firebase থেকে ডাটা আপডেট হয়েছে।";
};

// Init
App.init = function(){
  App.loadAll();
  App.initFirebase();

  document.getElementById("btnBackMenu").onclick = App.showMenu;

  const savedUser = localStorage.getItem("jp_user");
  if(savedUser){
    App.user = savedUser;
    App.showMenu();
  }else{
    document.getElementById("loginSection").classList.remove("hidden");
  }

  document.getElementById("btnLogin").onclick = ()=>{
    const name = document.getElementById("loginName").value.trim();
    const pass = document.getElementById("loginPassword").value.trim();
    const msg = document.getElementById("loginMsg");
    if(pass!==App.password){
      msg.textContent="পাসওয়ার্ড ভুল, আবার চেষ্টা করুন";
      return;
    }
    if(!name){
      msg.textContent="আপনার নাম লিখুন";
      return;
    }
    App.user = name;
    localStorage.setItem("jp_user",name);
    msg.textContent="";
    App.showMenu();
  };

  document.getElementById("btnExitApp").onclick = ()=>{
    alert("অ্যাপ থেকে বের হতে ব্রাউজারের ব্যাক বাটন ব্যবহার করুন।");
  };
};

App.showMenu = function(){
  document.getElementById("loginSection").classList.add("hidden");
  document.getElementById("pageSection").classList.add("hidden");
  document.getElementById("menuSection").classList.remove("hidden");
  document.getElementById("menuUserLabel").textContent="ইউজার: "+(App.user||"");

  const labels = [
    "১. প্রোডাক্ট যোগ করুন",
    "২. প্রোডাক্ট বিক্রি করুন",
    "৩. মোট প্রোডাক্ট ও স্টক",
    "৪. আজকের হিসেব",
    "৫. মোট বিক্রির হিসাব",
    "৬. মেয়াদ দেখুন",
    "৭. গ্রাহকের বাকি হিসাব",
    "৮. মোট লাভ",
    "৯. কোম্পানির টাকা পাবে",
    "১০. কোম্পানি মোট টাকা পরিশোধ",
    "১১. অন্যান্য খরচ",
    "১২. কর্মচারীদের হিসাব",
    "১৩. মোট বিক্রি",
    "১৪. মাসিক হিসেব",
    "১৫. কম্পানির মোবাইল নম্বর",
    "১৬. Firebase ব্যাকআপ / আপডেট"
  ];
  const grid = document.getElementById("menuGrid");
  grid.innerHTML="";
  labels.forEach((t,i)=>{
    const b=document.createElement("button");
    b.textContent=t;
    b.onclick=()=>App.openPage(i+1);
    grid.appendChild(b);
  });
};

App.openPage = function(no){
  document.getElementById("menuSection").classList.add("hidden");
  document.getElementById("pageSection").classList.remove("hidden");
  const title = document.getElementById("pageTitle");
  const content = document.getElementById("pageContent");
  content.innerHTML="";
  switch(no){
    case 1: title.textContent="প্রোডাক্ট যোগ করুন"; App.renderAddProduct(content); break;
    case 2: title.textContent="প্রোডাক্ট বিক্রি করুন"; App.renderSell(content); break;
    case 3: title.textContent="মোট প্রোডাক্ট ও স্টক"; App.renderStock(content); break;
    case 4: title.textContent="আজকের হিসেব"; App.renderToday(content); break;
    case 5: title.textContent="মোট বিক্রির হিসাব"; App.renderTotalSales(content); break;
    case 6: title.textContent="মেয়াদ দেখুন"; App.renderExpiry(content); break;
    case 7: title.textContent="গ্রাহকের বাকি হিসাব"; App.renderDue(content); break;
    case 8: title.textContent="মোট লাভ"; App.renderTotalSales(content); break;
    case 9: title.textContent="কোম্পানির টাকা পাবে"; App.renderCompanyReceive(content); break;
    case 10:title.textContent="কোম্পানি মোট টাকা পরিশোধ"; App.renderCompanyPay(content); break;
    case 11:title.textContent="অন্যান্য খরচ"; App.renderExpense(content); break;
    case 12:title.textContent="কর্মচারীদের হিসাব"; App.renderEmployee(content); break;
    case 13:title.textContent="মোট বিক্রি"; App.renderTotalSales(content); break;
    case 14:title.textContent="মাসিক হিসেব"; App.renderMonthly(content); break;
    case 15:title.textContent="কম্পানির মোবাইল নম্বর"; App.renderCompanyContacts(content); break;
    case 16:title.textContent="Firebase ব্যাকআপ / আপডেট"; App.renderFirebasePage(content); break;
  }
};

// ---------- প্রোডাক্ট যোগ ----------
App.renderAddProduct = function(root){
  const d=document.createElement("div");
  d.innerHTML=`
    <div class="flex">
      <div>
        <label>প্রোডাক্টের নাম</label>
        <input id="p_name" placeholder="Napa 500 ইত্যাদি">
      </div>
      <div>
        <label>কোম্পানির নাম</label>
        <input id="p_company">
      </div>
    </div>
    <div class="flex">
      <div>
        <label>বিক্রয় মূল্য</label>
        <input id="p_sell" type="number" step="0.01">
      </div>
      <div>
        <label>ক্রয় মূল্য (১২% কম)</label>
        <input id="p_buy" type="number" step="0.01">
      </div>
      <div>
        <label>পরিমাণ</label>
        <input id="p_qty" type="number">
      </div>
    </div>
    <div class="flex">
      <div>
        <label>মেয়াদ শেষের তারিখ</label>
        <input id="p_exp" type="date">
      </div>
      <div>
        <label>পেমেন্ট</label>
        <select id="p_pay">
          <option value="paid">পেইড</option>
          <option value="due">বাকি</option>
        </select>
      </div>
    </div>
    <p class="small">বিক্রয় মূল্য লিখলে ক্রয় মূল্য অটো ১২% কমে বসবে।</p>
    <div class="flex">
      <div><button id="btnCancel">বাদ দিন</button></div>
      <div><button id="btnSave" class="secondary">ADD করুন</button></div>
    </div>
    <p id="msg"></p>
  `;
  root.appendChild(d);
  const sell=d.querySelector("#p_sell");
  const buy=d.querySelector("#p_buy");
  sell.oninput=()=>{
    const v=parseFloat(sell.value||"0");
    if(v>0) buy.value=Math.round(v*0.88*100)/100;
  };
  d.querySelector("#btnCancel").onclick=App.showMenu;
  d.querySelector("#btnSave").onclick=()=>{
    const name=d.querySelector("#p_name").value.trim();
    const comp=d.querySelector("#p_company").value.trim();
    const s=parseFloat(sell.value||"0");
    const b=parseFloat(buy.value||"0");
    const q=parseInt(d.querySelector("#p_qty").value||"0",10);
    const exp=d.querySelector("#p_exp").value||"";
    const pay=d.querySelector("#p_pay").value;
    const msg=d.querySelector("#msg");
    if(!name||!comp||!s||!b||!q||!exp){
      msg.textContent="সব ঘর পূরণ করুন।";
      msg.className="error"; return;
    }
    App.state.products.push({
      id:Date.now(),
      name,company:comp,
      sellPrice:s,buyPrice:b,
      qty:q,expiry:exp,payment:pay
    });
    App.saveAll();
    msg.textContent="প্রোডাক্ট সেভ হয়েছে।";
    msg.className="success";
    d.querySelectorAll("input").forEach(i=>i.value="");
    d.querySelector("#p_pay").value="paid";
  };
};

// ---------- প্রোডাক্ট বিক্রি ----------
App.renderSell = function(root){
  const d=document.createElement("div");
  d.innerHTML=`
    <div class="flex">
      <div>
        <label>ম্যানুয়াল সার্চ</label>
        <input id="s_query" placeholder="নাম বা কোম্পানি লিখুন...">
      </div>
      <div>
        <label>স্ক্যান মোড (ক্যামেরা)</label>
        <button id="btnCam" class="secondary">ক্যামেরা থেকে স্ক্যান করুন</button>
        <input id="s_cam" type="file" accept="image/*" capture="environment" style="display:none">
        <span class="small">স্ক্যান করতে ইন্টারনেট অন থাকতে হবে (Tesseract.js)</span>
      </div>
    </div>
    <p id="scanMsg" class="small"></p>
    <table>
      <thead><tr><th>নাম</th><th>কোম্পানি</th><th>স্টক</th><th>দাম</th><th>+</th></tr></thead>
      <tbody id="s_list"></tbody>
    </table>

    <h3>কার্ট</h3>
    <table>
      <thead><tr><th>নাম</th><th>পরিমাণ</th><th>দাম</th><th>মোট</th><th>×</th></tr></thead>
      <tbody id="cart_list"></tbody>
    </table>
    <p id="cart_total"></p>
    <button id="btnCash" class="primary">পূর্ণ টাকা (ক্যাশ)</button>
    <button id="btnDue" class="secondary">বাকি থাকবে</button>
    <p id="sellMsg"></p>
  `;
  root.appendChild(d);
  let cart=[];

  function renderProducts(filter){
    const tb=d.querySelector("#s_list");
    tb.innerHTML="";
    const q=(filter||"").toLowerCase();
    App.state.products.forEach(p=>{
      if(q && !(`${p.name} ${p.company}`.toLowerCase().includes(q))) return;
      const tr=document.createElement("tr");
      tr.innerHTML=`<td>${p.name}</td><td>${p.company}</td><td>${p.qty}</td><td>${p.sellPrice}</td>`;
      const td=document.createElement("td");
      const b=document.createElement("button");
      b.textContent="+";
      b.onclick=()=>addToCart(p);
      td.appendChild(b);
      tr.appendChild(td);
      tb.appendChild(tr);
    });
  }
  function addToCart(p){
    let item=cart.find(c=>c.id===p.id);
    if(!item){item={id:p.id,name:p.name,price:p.sellPrice,buy:p.buyPrice,qty:0};cart.push(item);}
    const stock=App.state.products.find(x=>x.id===p.id).qty;
    if(item.qty>=stock){alert("স্টকে নেই");return;}
    item.qty++; renderCart();
  }
  function renderCart(){
    const tb=d.querySelector("#cart_list"); tb.innerHTML="";
    let total=0;
    cart.forEach((c,i)=>{
      const row=c.qty*c.price; total+=row;
      const tr=document.createElement("tr");
      tr.innerHTML=`<td>${c.name}</td><td>${c.qty}</td><td>${c.price}</td><td>${row}</td>`;
      const td=document.createElement("td");
      const b=document.createElement("button");
      b.textContent="×";
      b.onclick=()=>{cart.splice(i,1);renderCart();};
      td.appendChild(b); tr.appendChild(td); tb.appendChild(tr);
    });
    d.querySelector("#cart_total").textContent="মোট দাম: "+total+" টাকা";
  }

  d.querySelector("#s_query").oninput=e=>renderProducts(e.target.value);

  const cam=d.querySelector("#s_cam");
  d.querySelector("#btnCam").onclick=()=>cam.click();
  cam.onchange=async e=>{
    const file=e.target.files[0];
    const msg=d.querySelector("#scanMsg");
    if(!file) return;
    if(typeof Tesseract==="undefined"){msg.textContent="Tesseract.js লোড হয়নি।";return;}
    msg.textContent="স্ক্যান হচ্ছে...";
    try{
      const {data:{text}}=await Tesseract.recognize(file,"eng");
      msg.textContent="স্ক্যান ফলাফল: "+text;
      const first=(text.split(/\s+/).find(w=>w.length>1)||"").toLowerCase();
      if(first){
        const found=App.state.products.find(p=>p.name.toLowerCase().includes(first));
        if(found){
          addToCart(found);
          d.querySelector("#s_query").value=first;
          renderProducts(first);
          msg.textContent+=" → "+found.name+" কার্টে যোগ হয়েছে";
        }else msg.textContent+=" → মিল পাওয়া যায়নি";
      }else msg.textContent+=" → পড়া যায়নি";
    }catch(err){msg.textContent="সমস্যা: "+err.message;}
  };

  async function finalizeSale(isDue){
    if(!cart.length){d.querySelector("#sellMsg").textContent="কার্ট খালি।";return;}
    let customerName="",phone="";
    if(isDue){
      customerName=prompt("গ্রাহকের নাম:","")||"বাকি গ্রাহক";
      phone=prompt("মোবাইল নম্বর:","")||"";
    }
    const today=App.today(); let totalSell=0,totalProfit=0;
    cart.forEach(c=>{
      const prod=App.state.products.find(p=>p.id===c.id); if(!prod)return;
      prod.qty-=c.qty;
      const sellTotal=c.qty*c.price;
      const buyTotal=c.qty*c.buy;
      const profit=sellTotal-buyTotal;
      totalSell+=sellTotal; totalProfit+=profit;
      App.state.sales.push({
        id:Date.now()+Math.random(),
        date:today,
        productId:prod.id,
        productName:prod.name,
        qty:c.qty,
        sellTotal,buyTotal,profit,
        isDue,customerName,phone
      });
    });
    if(isDue){
      let due=App.state.dues.find(d=>d.customerName===customerName && d.phone===phone);
      if(!due){due={id:Date.now(),customerName,phone,amount:0};App.state.dues.push(due);}
      due.amount+=totalSell;
    }
    App.saveAll();
    cart=[]; renderCart(); renderProducts(d.querySelector("#s_query").value);
    d.querySelector("#sellMsg").textContent="বিক্রি সম্পন্ন। মোট বিক্রি "+totalSell+" টাকা, লাভ "+totalProfit+" টাকা";
  }

  d.querySelector("#btnCash").onclick=()=>finalizeSale(false);
  d.querySelector("#btnDue").onclick=()=>finalizeSale(true);

  renderProducts("");
};

// ---------- Stock ----------
App.renderStock = function(root){
  const t=document.createElement("table");
  t.innerHTML=`<thead><tr><th>নাম</th><th>কোম্পানি</th><th>ক্রয়</th><th>বিক্রয়</th><th>স্টক</th><th>একক লাভ</th></tr></thead><tbody></tbody>`;
  const tb=t.querySelector("tbody");
  let poss=0;
  App.state.products.forEach(p=>{
    const unit=p.sellPrice-p.buyPrice;
    poss+=unit*p.qty;
    const tr=document.createElement("tr");
    tr.innerHTML=`<td>${p.name}</td><td>${p.company}</td><td>${p.buyPrice}</td><td>${p.sellPrice}</td><td>${p.qty}</td><td>${unit}</td>`;
    tb.appendChild(tr);
  });
  root.appendChild(t);
  const p=document.createElement("p");
  p.textContent="সব প্রোডাক্ট বিক্রি করলে সম্ভাব্য মোট লাভ: "+poss+" টাকা";
  root.appendChild(p);
};

// ---------- Today ----------
App.renderToday = function(root){
  const day=App.today();
  const sales=App.state.sales.filter(s=>s.date===day);
  const exps=App.state.expenses.filter(e=>e.date===day);
  let totalSell=0,totalProfit=0,totalExp=0;
  const ul=document.createElement("ul");
  sales.forEach(s=>{
    totalSell+=s.sellTotal; totalProfit+=s.profit;
    const li=document.createElement("li");
    li.textContent=`বিক্রি: ${s.productName} x${s.qty} = ${s.sellTotal} (লাভ ${s.profit})`;
    ul.appendChild(li);
  });
  exps.forEach(e=>{
    totalExp+=e.amount;
    const li=document.createElement("li");
    li.textContent=`খরচ: ${e.amount} - ${e.note}`;
    ul.appendChild(li);
  });
  root.appendChild(ul);
  const p=document.createElement("p");
  p.textContent=`আজকের মোট বিক্রি: ${totalSell} টাকা, লাভ: ${totalProfit} টাকা, খরচ: ${totalExp} টাকা`;
  root.appendChild(p);
};

// ---------- Total sales / profit ----------
App.renderTotalSales = function(root){
  let totalSell=0,totalProfit=0;
  const t=document.createElement("table");
  t.innerHTML=`<thead><tr><th>তারিখ</th><th>প্রোডাক্ট</th><th>Qty</th><th>বিক্রি</th><th>লাভ</th></tr></thead><tbody></tbody>`;
  const tb=t.querySelector("tbody");
  App.state.sales.forEach(s=>{
    totalSell+=s.sellTotal; totalProfit+=s.profit;
    const tr=document.createElement("tr");
    tr.innerHTML=`<td>${s.date}</td><td>${s.productName}</td><td>${s.qty}</td><td>${s.sellTotal}</td><td>${s.profit}</td>`;
    tb.appendChild(tr);
  });
  root.appendChild(t);
  const p=document.createElement("p");
  p.textContent=`মোট বিক্রি: ${totalSell} টাকা, মোট লাভ: ${totalProfit} টাকা`;
  root.appendChild(p);
};

// ---------- Expiry ----------
App.renderExpiry = function(root){
  const today=new Date(App.today());
  const t=document.createElement("table");
  t.innerHTML=`<thead><tr><th>নাম</th><th>কোম্পানি</th><th>মেয়াদ</th><th>বাকি দিন</th></tr></thead><tbody></tbody>`;
  const tb=t.querySelector("tbody");
  App.state.products.forEach(p=>{
    if(!p.expiry)return;
    const exp=new Date(p.expiry);
    const diff=Math.round((exp-today)/(1000*60*60*24));
    let cls="badge badge-ok";
    if(diff<0)cls="badge badge-bad"; else if(diff<=30)cls="badge badge-warn";
    const tr=document.createElement("tr");
    tr.innerHTML=`<td>${p.name}</td><td>${p.company}</td><td>${p.expiry}</td><td><span class="${cls}">${diff} দিন</span></td>`;
    tb.appendChild(tr);
  });
  root.appendChild(t);
};

// ---------- Due ----------
App.renderDue = function(root){
  const t=document.createElement("table");
  t.innerHTML=`<thead><tr><th>নাম</th><th>মোবাইল</th><th>বাকি</th></tr></thead><tbody></tbody>`;
  const tb=t.querySelector("tbody");
  let total=0;
  App.state.dues.forEach(d=>{
    total+=d.amount;
    const tr=document.createElement("tr");
    tr.innerHTML=`<td>${d.customerName}</td><td>${d.phone}</td><td>${d.amount}</td>`;
    tb.appendChild(tr);
  });
  root.appendChild(t);
  const p=document.createElement("p");
  p.textContent="সব গ্রাহকের মোট বাকি: "+total+" টাকা";
  root.appendChild(p);
};

// ---------- Company receive ----------
App.renderCompanyReceive = function(root){
  const d=document.createElement("div");
  d.innerHTML=`
    <div class="flex">
      <div><label>তারিখ</label><input id="cr_date" type="date"></div>
      <div><label>কোম্পানির নাম</label><input id="cr_name"></div>
      <div><label>মোবাইল নম্বর</label><input id="cr_phone"></div>
      <div><label>টাকা পাবে</label><input id="cr_amount" type="number" step="0.01"></div>
    </div>
    <button id="cr_save" class="secondary">সেভ করুন</button>
    <p id="cr_msg"></p>
    <table><thead><tr><th>তারিখ</th><th>কোম্পানি</th><th>মোবাইল</th><th>টাকা পাবে</th></tr></thead><tbody id="cr_list"></tbody></table>
  `;
  root.appendChild(d);
  d.querySelector("#cr_date").value=App.today();
  function render(){
    const tb=d.querySelector("#cr_list"); tb.innerHTML=""; let total=0;
    App.state.compReceive.forEach(r=>{
      total+=r.amount;
      const tr=document.createElement("tr");
      tr.innerHTML=`<td>${r.date}</td><td>${r.company}</td><td>${r.phone}</td><td>${r.amount}</td>`;
      tb.appendChild(tr);
    });
    d.querySelector("#cr_msg").textContent="মোট পাওনা: "+total+" টাকা";
  }
  d.querySelector("#cr_save").onclick=()=>{
    const date=d.querySelector("#cr_date").value||App.today();
    const name=d.querySelector("#cr_name").value.trim();
    const phone=d.querySelector("#cr_phone").value.trim();
    const amt=parseFloat(d.querySelector("#cr_amount").value||"0");
    if(!name||!amt){d.querySelector("#cr_msg").textContent="কোম্পানির নাম ও টাকা দিন।";return;}
    App.state.compReceive.push({id:Date.now(),date,company:name,phone,amount:amt});
    App.saveAll();
    d.querySelector("#cr_name").value="";d.querySelector("#cr_phone").value="";d.querySelector("#cr_amount").value="";
    render();
  };
  render();
};

// ---------- Company pay ----------
App.renderCompanyPay = function(root){
  const d=document.createElement("div");
  d.innerHTML=`
    <div class="flex">
      <div><label>তারিখ</label><input id="cp_date" type="date"></div>
      <div><label>কোম্পানির নাম</label><input id="cp_name"></div>
      <div><label>মোবাইল নম্বর</label><input id="cp_phone"></div>
      <div><label>টাকা দিয়েছি</label><input id="cp_amount" type="number" step="0.01"></div>
    </div>
    <button id="cp_save" class="secondary">সেভ করুন</button>
    <p id="cp_msg"></p>
    <table><thead><tr><th>তারিখ</th><th>কোম্পানি</th><th>মোবাইল</th><th>টাকা দিয়েছি</th></tr></thead><tbody id="cp_list"></tbody></table>
  `;
  root.appendChild(d);
  d.querySelector("#cp_date").value=App.today();
  function render(){
    const tb=d.querySelector("#cp_list"); tb.innerHTML=""; let total=0;
    App.state.compPay.forEach(r=>{
      total+=r.amount;
      const tr=document.createElement("tr");
      tr.innerHTML=`<td>${r.date}</td><td>${r.company}</td><td>${r.phone}</td><td>${r.amount}</td>`;
      tb.appendChild(tr);
    });
    d.querySelector("#cp_msg").textContent="মোট পরিশোধ: "+total+" টাকা";
  }
  d.querySelector("#cp_save").onclick=()=>{
    const date=d.querySelector("#cp_date").value||App.today();
    const name=d.querySelector("#cp_name").value.trim();
    const phone=d.querySelector("#cp_phone").value.trim();
    const amt=parseFloat(d.querySelector("#cp_amount").value||"0");
    if(!name||!amt){d.querySelector("#cp_msg").textContent="কোম্পানির নাম ও টাকা দিন।";return;}
    App.state.compPay.push({id:Date.now(),date,company:name,phone,amount:amt});
    App.saveAll();
    d.querySelector("#cp_name").value="";d.querySelector("#cp_phone").value="";d.querySelector("#cp_amount").value="";
    render();
  };
  render();
};

// ---------- Expense ----------
App.renderExpense = function(root){
  const d=document.createElement("div");
  d.innerHTML=`
    <div class="flex">
      <div><label>তারিখ</label><input id="ex_date" type="date"></div>
      <div><label>টাকার পরিমাণ</label><input id="ex_amount" type="number" step="0.01"></div>
    </div>
    <label>খরচের বর্ণনা</label>
    <textarea id="ex_note"></textarea>
    <button id="ex_save" class="secondary">সেভ করুন</button>
    <p id="ex_msg"></p>
    <table><thead><tr><th>তারিখ</th><th>টাকা</th><th>বর্ণনা</th></tr></thead><tbody id="ex_list"></tbody></table>
  `;
  root.appendChild(d);
  d.querySelector("#ex_date").value=App.today();
  function render(){
    const tb=d.querySelector("#ex_list"); tb.innerHTML=""; let total=0;
    App.state.expenses.forEach(e=>{
      total+=e.amount;
      const tr=document.createElement("tr");
      tr.innerHTML=`<td>${e.date}</td><td>${e.amount}</td><td>${e.note}</td>`;
      tb.appendChild(tr);
    });
    d.querySelector("#ex_msg").textContent="মোট অন্যান্য খরচ: "+total+" টাকা";
  }
  d.querySelector("#ex_save").onclick=()=>{
    const date=d.querySelector("#ex_date").value||App.today();
    const amt=parseFloat(d.querySelector("#ex_amount").value||"0");
    const note=d.querySelector("#ex_note").value.trim();
    if(!amt){d.querySelector("#ex_msg").textContent="টাকার পরিমাণ দিন।";return;}
    App.state.expenses.push({id:Date.now(),date,amount:amt,note});
    App.saveAll();
    d.querySelector("#ex_amount").value="";d.querySelector("#ex_note").value="";
    render();
  };
  render();
};

// ---------- Employee ----------
App.renderEmployee = function(root){
  const d=document.createElement("div");
  d.innerHTML=`
    <div class="flex">
      <div><label>কর্মচারীর নাম</label><input id="em_name"></div>
      <div><label>বেতন</label><input id="em_salary" type="number" step="0.01"></div>
      <div><label>দিয়েছি</label><input id="em_paid" type="number" step="0.01"></div>
    </div>
    <label>নোট</label>
    <textarea id="em_note"></textarea>
    <button id="em_save" class="secondary">সেভ করুন</button>
    <p id="em_msg"></p>
    <table><thead><tr><th>নাম</th><th>বেতন</th><th>দিয়েছি</th><th>নোট</th></tr></thead><tbody id="em_list"></tbody></table>
  `;
  root.appendChild(d);
  function render(){
    const tb=d.querySelector("#em_list"); tb.innerHTML=""; let ts=0,tp=0;
    App.state.employees.forEach(e=>{
      ts+=e.salary; tp+=e.paid;
      const tr=document.createElement("tr");
      tr.innerHTML=`<td>${e.name}</td><td>${e.salary}</td><td>${e.paid}</td><td>${e.note}</td>`;
      tb.appendChild(tr);
    });
    d.querySelector("#em_msg").textContent="মোট বেতন: "+ts+" | মোট প্রদান: "+tp;
  }
  d.querySelector("#em_save").onclick=()=>{
    const name=d.querySelector("#em_name").value.trim();
    const sal=parseFloat(d.querySelector("#em_salary").value||"0");
    const paid=parseFloat(d.querySelector("#em_paid").value||"0");
    const note=d.querySelector("#em_note").value.trim();
    if(!name||!sal){d.querySelector("#em_msg").textContent="নাম ও বেতন দিন।";return;}
    App.state.employees.push({id:Date.now(),name,salary:sal,paid, note});
    App.saveAll();
    d.querySelector("#em_name").value="";d.querySelector("#em_salary").value="";d.querySelector("#em_paid").value="";d.querySelector("#em_note").value="";
    render();
  };
  render();
};

// ---------- Monthly ----------
App.renderMonthly = function(root){
  const ym=App.today().slice(0,7);
  let totalSell=0,totalProfit=0,totalExp=0;
  App.state.sales.forEach(s=>{
    if(s.date && s.date.startsWith(ym)){totalSell+=s.sellTotal;totalProfit+=s.profit;}
  });
  App.state.expenses.forEach(e=>{
    if(e.date && e.date.startsWith(ym)) totalExp+=e.amount;
  });
  const p=document.createElement("p");
  p.textContent=`${ym} মাস পর্যন্ত মোট বিক্রি: ${totalSell} টাকা, লাভ: ${totalProfit} টাকা, খরচ: ${totalExp} টাকা`;
  root.appendChild(p);
};

// ---------- Company contacts ----------
App.renderCompanyContacts = function(root){
  const d=document.createElement("div");
  d.innerHTML=`
    <div class="flex">
      <div><label>নাম</label><input id="cc_person"></div>
      <div><label>কোম্পানির নাম</label><input id="cc_company"></div>
      <div><label>মোবাইল নম্বর</label><input id="cc_phone"></div>
    </div>
    <button id="cc_save" class="secondary">সেভ করুন</button>
    <p id="cc_msg"></p>
    <table><thead><tr><th>নাম</th><th>কোম্পানি</th><th>মোবাইল নম্বর</th></tr></thead><tbody id="cc_list"></tbody></table>
  `;
  root.appendChild(d);
  function render(){
    const tb=d.querySelector("#cc_list"); tb.innerHTML="";
    App.state.compContacts.forEach(c=>{
      const tr=document.createElement("tr");
      tr.innerHTML=`<td>${c.person}</td><td>${c.company}</td><td>${c.phone}</td>`;
      tb.appendChild(tr);
    });
  }
  d.querySelector("#cc_save").onclick=()=>{
    const person=d.querySelector("#cc_person").value.trim();
    const comp=d.querySelector("#cc_company").value.trim();
    const phone=d.querySelector("#cc_phone").value.trim();
    if(!comp||!phone){d.querySelector("#cc_msg").textContent="কোম্পানির নাম ও মোবাইল দিন।";return;}
    App.state.compContacts.push({id:Date.now(),person,company:comp,phone});
    App.saveAll();
    d.querySelector("#cc_person").value="";d.querySelector("#cc_company").value="";d.querySelector("#cc_phone").value="";
    d.querySelector("#cc_msg").textContent="সেভ হয়েছে।";
    render();
  };
  render();
};

// ---------- Firebase page ----------
App.renderFirebasePage = function(root){
  const d=document.createElement("div");
  d.innerHTML=`
    <p class="small">ইন্টারনেট থাকলে নিচের বাটন থেকে Firebase-এ ডাটা ব্যাকআপ ও ফিরিয়ে নিতে পারবেন।</p>
    <button id="fb_up" class="secondary">Firebase এ সব ডাটা আপলোড করুন</button>
    <button id="fb_down" class="primary">Firebase থেকে সর্বশেষ ডাটা নিন</button>
    <p id="fb_status"></p>
  `;
  root.appendChild(d);
  const st=d.querySelector("#fb_status");
  d.querySelector("#fb_up").onclick=()=>App.firebaseUpload(st);
  d.querySelector("#fb_down").onclick=()=>App.firebaseDownload(st);
};

window.addEventListener("load",App.init);